﻿using System;

namespace Shared.Models
{
    public class Class1
    {
    }
}
