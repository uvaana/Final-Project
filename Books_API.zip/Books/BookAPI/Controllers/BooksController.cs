﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BookAPI.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;


namespace BookAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly ImageDBContext _db;
        public BooksController(ImageDBContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var books = await _db.TblData.ToListAsync();
            return Ok(books);
        }

        [HttpPost]
        
        public async Task<IActionResult> Post(TblDatum tblDatum)
        {
            _db.TblData.Add(tblDatum);
            await _db.SaveChangesAsync();
            return Ok(tblDatum);
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var booksById = await _db
            .TblData.Where(_ => _.Id == id)
            .FirstOrDefaultAsync();
            return Ok(booksById);
        }

        [HttpPut]
        
        public async Task<IActionResult> Put(TblDatum tblDatum)
        {
            _db.TblData.Update(tblDatum);
            await _db.SaveChangesAsync();
            return Ok(tblDatum);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var booksToDelete = await _db.TblData.FindAsync(id);
            if (booksToDelete == null)
            {
                return NotFound();
            }
            _db.TblData.Remove(booksToDelete);
            await _db.SaveChangesAsync();
            return Ok();
        }
    }
}
