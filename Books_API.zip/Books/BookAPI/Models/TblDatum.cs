﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BookAPI.Models
{
    public partial class TblDatum
    {
        public int Id { get; set; }
        public string Logo { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public int? Price { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public DateTime? PublishedDate { get; set; }
        public string Chapters { get; set; }
    }
}
